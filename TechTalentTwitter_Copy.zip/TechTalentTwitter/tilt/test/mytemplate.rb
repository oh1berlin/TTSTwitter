class MyTemplate
end
