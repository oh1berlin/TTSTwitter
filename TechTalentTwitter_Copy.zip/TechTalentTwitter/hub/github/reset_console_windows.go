// +build windows

package github

import "github.com/github/hub/cmd"

// This does nothing on windows
func setConsole(cmd *cmd.Cmd) {
}
