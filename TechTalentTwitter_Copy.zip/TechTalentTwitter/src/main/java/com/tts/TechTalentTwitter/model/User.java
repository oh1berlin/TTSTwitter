/**
 * 
 */
package com.tts.TechTalentTwitter.model;

import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.validator.constraints.Length;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author lappymclappyface
 *
 */

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity

public class User {
@Id
@GeneratedValue (strategy = GenerationType.AUTO)
@Column(name = "user_id")
private Long id;


@Email(message= "Please provide a valid email address.")
@NotEmpty(message= "Please provide a valid email address.")
private String email;

@NotEmpty(message= "Please provide a user name.")
@Length (min=3, message="Your username must have more than three characters")
@Length(max=25, message="Your username cannot have more than 25 characters")
@Pattern (regexp="[^\\s]+", message="Your username cannot contain spaces")
private String username;

@Length(min=5, message= "Your password must have more than five characters")
@NotEmpty (message="Please provide a password")
@JsonProperty(access=Access.WRITE_ONLY)
private String password;

@NotEmpty(message="Please enter your first name")

private String firstName;
@NotEmpty(message ="Please enter your last name")
private String lastName;
private int active;

@CreationTimestamp
private Date createdAt;

@ManyToMany (cascade =CascadeType.ALL)
@JoinTable (name="user_role", joinColumns=@JoinColumn(name="user_id"), inverseJoinColumns=@JoinColumn(name="role_id"))
private Set <Role> roles;

public User(Long id,
		@Email(message = "Please provide a valid email address.") @NotEmpty(message = "Please provide a valid email address.") String email,
		@NotEmpty(message = "Please provide a user name.") @Length(min = 3, message = "Your username must have more than three characters") @Length(max = 25, message = "Your username cannot have more than 25 characters") @Pattern(regexp = "[^\\s]+", message = "Your username cannot contain spaces") String username,
		@Length(min = 5, message = "Your password must have more than five characters") @NotEmpty(message = "Please provide a password") String password,
		@NotEmpty(message = "Please enter your first name") String firstName,
		@NotEmpty(message = "Please enter your last name") String lastName, int active, Date createdAt, Set<Role> roles,
		List<User> followers, List<User> following) {
	
	this.id = id;
	this.email = email;
	this.username = username;
	this.password = password;
	this.firstName = firstName;
	this.lastName = lastName;
	this.active = active;
	this.createdAt = createdAt;
	this.roles = roles;
	this.followers = followers;
	this.following = following;
}
public User() {
	
	
	
}

/**
 * @return the id
 */
public Long getId() {
	return id;
}

/**
 * @param id the id to set
 */
public void setId(Long id) {
	this.id = id;
}

/**
 * @return the email
 */
public String getEmail() {
	return email;
}

/**
 * @param email the email to set
 */
public void setEmail(String email) {
	this.email = email;
}

/**
 * @return the username
 */
public String getUsername() {
	return username;
}

/**
 * @param username the username to set
 */
public void setUsername(String username) {
	this.username = username;
}

/**
 * @return the password
 */
public String getPassword() {
	return password;
}

/**
 * @param password the password to set
 */
public void setPassword(String password) {
	this.password = password;
}

/**
 * @return the firstName
 */
public String getFirstName() {
	return firstName;
}

/**
 * @param firstName the firstName to set
 */
public void setFirstName(String firstName) {
	this.firstName = firstName;
}

/**
 * @return the lastName
 */
public String getLastName() {
	return lastName;
}

/**
 * @param lastName the lastName to set
 */
public void setLastName(String lastName) {
	this.lastName = lastName;
}

/**
 * @return the active
 */
public int getActive() {
	return active;
}

/**
 * @param active the active to set
 */
public void setActive(int active) {
	this.active = active;
}

/**
 * @return the createdAt
 */
public Date getCreatedAt() {
	return createdAt;
}

/**
 * @param createdAt the createdAt to set
 */
public void setCreatedAt(Date createdAt) {
	this.createdAt = createdAt;
}

/**
 * @return the roles
 */
public Set<Role> getRoles() {
	return roles;
}

/**
 * @param roles the roles to set
 */
public void setRoles(Set<Role> roles) {
	this.roles = roles;
}

/**
 * @return the followers
 */
public List<User> getFollowers() {
	return followers;
}

/**
 * @param followers the followers to set
 */
public void setFollowers(List<User> followers) {
	this.followers = followers;
}

/**
 * @return the following
 */
public List<User> getFollowing() {
	return following;
}

/**
 * @param following the following to set
 */
public void setFollowing(List<User> following) {
	this.following = following;
}

@ManyToMany(cascade=CascadeType.ALL)
@JoinTable(name="user_follower", joinColumns=@JoinColumn(name="user_id"), inverseJoinColumns=@JoinColumn(name="follower_id"))
private List <User> followers;

@ManyToMany(mappedBy="followers")
private List<User> following;




@Email(message = "Please provide a valid email")
@NotEmpty(message = "Please provide an email")
private String email1;
    
@Length(min = 3, message = "Your username must have at least 3 characters")
@Length(max = 15, message = "Your username cannot have more than 15 characters")
@Pattern(regexp="[^\\s]+", message="Your username cannot contain spaces")
private String username1;
    
@Length(min = 5, message = "Your password must have at least 5 characters")
private String password1;
    
@NotEmpty(message = "Please provide your first name")
private String firstName1;
    
@NotEmpty(message = "Please provide your last name")
private String lastName1;
}
