package com.tts.TechTalentTwitter.model;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotEmpty;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import org.hibernate.validator.constraints.Length;
import org.ocpsoft.prettytime.PrettyTime;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Tweet {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "tweet_id")
	private Long id;
		
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "user_id")
	@OnDelete(action = OnDeleteAction.CASCADE)
	private User user;
		
	private String message1;
		
	@CreationTimestamp 
	private Date createdAt;

	public void setUser(User user2) {
		// TODO Auto-generated method stub
		
	}
	
	@NotEmpty(message = "Tweet cannot be empty")
	@Length(max = 280, message = "Tweet cannot have more than 280 characters")
	private String message;

	public void setMessage(String message2) {
		// TODO Auto-generated method stub
		
	}

	public void setTags(List<Tag> tags) {
		// TODO Auto-generated method stub
		
	}
	private List<TweetDisplay> formatTweets(List<Tweet> tweets) {
	    addTagLinks(tweets);
	    shortenLinks(tweets);
	    List<TweetDisplay> displayTweets = formatTweets(tweets);
	    return displayTweets;}
	    
	    private List<TweetDisplay> formatTimestamps(List<Tweet> tweets){
	        List<TweetDisplay> response = new ArrayList<>();
			return response;
			        
			    }
	private Object getUser() {
			// TODO Auto-generated method stub
			return null;
		}
	
	private Object getCreatedAt() {
			// TODO Auto-generated method stub
			return null;
		}

	private void shortenLinks(List<Tweet> tweets) {
		// TODO Auto-generated method stub
		
	}

	private void addTagLinks(List<Tweet> tweets) {
		// TODO Auto-generated method stub
		
	}

	public String getMessage() {
		// TODO Auto-generated method stub
		return null;
	}


}
