package com.tts.TechTalentTwitter.model;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TweetDisplay {
    private User user;
	
    private String message;
	
	private String date;
	
    private List<Tag> tags;

	public void setMessage(String message2) {
		// TODO Auto-generated method stub
		
	}

	public void setDate(String format) {
		// TODO Auto-generated method stub
		
	}

	public void setUser(Object user2) {
		// TODO Auto-generated method stub
		
	}

	public void setTags(Class<? extends Tweet> class1) {
		// TODO Auto-generated method stub
		
	}
}

